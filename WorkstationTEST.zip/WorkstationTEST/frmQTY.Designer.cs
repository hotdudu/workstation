﻿namespace WorkstationTEST
{
    partial class frmQTY
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button frmNumbtnD;
            this.frmNumshowno = new System.Windows.Forms.TextBox();
            this.frmNumRecordnow = new System.Windows.Forms.Label();
            this.NumPanel = new System.Windows.Forms.TableLayoutPanel();
            this.frmNumbtnU = new System.Windows.Forms.Button();
            this.SaveStat = new System.Windows.Forms.Label();
            this.save = new WorkstationTEST.XButton();
            this.chkouside = new System.Windows.Forms.CheckBox();
            this.btnoutside = new WorkstationTEST.XButton();
            this.RIPanel = new System.Windows.Forms.TableLayoutPanel();
            this.focust = new System.Windows.Forms.TextBox();
            this.Qpanel = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Qpanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.frmQTYname = new System.Windows.Forms.Label();
            frmNumbtnD = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // frmNumbtnD
            // 
            frmNumbtnD.Location = new System.Drawing.Point(733, 454);
            frmNumbtnD.Name = "frmNumbtnD";
            frmNumbtnD.Size = new System.Drawing.Size(75, 23);
            frmNumbtnD.TabIndex = 11;
            frmNumbtnD.Text = "frmNumbtnD";
            frmNumbtnD.UseVisualStyleBackColor = true;
            frmNumbtnD.Visible = false;
            // 
            // frmNumshowno
            // 
            this.frmNumshowno.Location = new System.Drawing.Point(444, 387);
            this.frmNumshowno.Name = "frmNumshowno";
            this.frmNumshowno.Size = new System.Drawing.Size(174, 22);
            this.frmNumshowno.TabIndex = 14;
            this.frmNumshowno.Visible = false;
            // 
            // frmNumRecordnow
            // 
            this.frmNumRecordnow.AutoSize = true;
            this.frmNumRecordnow.Location = new System.Drawing.Point(617, 552);
            this.frmNumRecordnow.Name = "frmNumRecordnow";
            this.frmNumRecordnow.Size = new System.Drawing.Size(99, 12);
            this.frmNumRecordnow.TabIndex = 13;
            this.frmNumRecordnow.Text = "frmNumRecordnow";
            this.frmNumRecordnow.Visible = false;
            // 
            // NumPanel
            // 
            this.NumPanel.AutoSize = true;
            this.NumPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.NumPanel.ColumnCount = 4;
            this.NumPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.NumPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.NumPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.NumPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.NumPanel.Location = new System.Drawing.Point(12, 79);
            this.NumPanel.Name = "NumPanel";
            this.NumPanel.RowCount = 3;
            this.NumPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.NumPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.NumPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.NumPanel.Size = new System.Drawing.Size(0, 0);
            this.NumPanel.TabIndex = 9;
            // 
            // frmNumbtnU
            // 
            this.frmNumbtnU.Location = new System.Drawing.Point(765, 184);
            this.frmNumbtnU.Name = "frmNumbtnU";
            this.frmNumbtnU.Size = new System.Drawing.Size(75, 23);
            this.frmNumbtnU.TabIndex = 10;
            this.frmNumbtnU.Text = "frmNumbtnU";
            this.frmNumbtnU.UseVisualStyleBackColor = true;
            this.frmNumbtnU.Visible = false;
            // 
            // SaveStat
            // 
            this.SaveStat.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveStat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.SaveStat.Location = new System.Drawing.Point(487, 33);
            this.SaveStat.Name = "SaveStat";
            this.SaveStat.Size = new System.Drawing.Size(164, 33);
            this.SaveStat.TabIndex = 15;
            this.SaveStat.Text = "label1";
            this.SaveStat.Visible = false;
            // 
            // save
            // 
            this.save.LeftText = null;
            this.save.Location = new System.Drawing.Point(922, 429);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(86, 73);
            this.save.TabIndex = 12;
            this.save.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.save.TopText = null;
            this.save.UseVisualStyleBackColor = true;
            // 
            // chkouside
            // 
            this.chkouside.AutoSize = true;
            this.chkouside.Checked = true;
            this.chkouside.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkouside.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.chkouside.Location = new System.Drawing.Point(922, 281);
            this.chkouside.Name = "chkouside";
            this.chkouside.Size = new System.Drawing.Size(139, 25);
            this.chkouside.TabIndex = 17;
            this.chkouside.Text = "產生外包單";
            this.chkouside.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.chkouside.UseVisualStyleBackColor = true;
            // 
            // btnoutside
            // 
            this.btnoutside.LeftText = null;
            this.btnoutside.Location = new System.Drawing.Point(922, 312);
            this.btnoutside.Name = "btnoutside";
            this.btnoutside.Size = new System.Drawing.Size(75, 23);
            this.btnoutside.TabIndex = 18;
            this.btnoutside.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnoutside.TopText = null;
            this.btnoutside.UseVisualStyleBackColor = true;
            this.btnoutside.Visible = false;
            this.btnoutside.Click += new System.EventHandler(this.btnoutside_Click);
            // 
            // RIPanel
            // 
            this.RIPanel.AutoSize = true;
            this.RIPanel.ColumnCount = 3;
            this.RIPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.RIPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.RIPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.RIPanel.Location = new System.Drawing.Point(2, 12);
            this.RIPanel.Name = "RIPanel";
            this.RIPanel.RowCount = 2;
            this.RIPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.RIPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.RIPanel.Size = new System.Drawing.Size(209, 67);
            this.RIPanel.TabIndex = 19;
            // 
            // focust
            // 
            this.focust.Location = new System.Drawing.Point(678, 497);
            this.focust.Name = "focust";
            this.focust.Size = new System.Drawing.Size(174, 22);
            this.focust.TabIndex = 20;
            this.focust.Visible = false;
            // 
            // Qpanel
            // 
            this.Qpanel.AutoScroll = true;
            this.Qpanel.ColumnCount = 6;
            this.Qpanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.Qpanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.Qpanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.Qpanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.Qpanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.Qpanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.Qpanel.Location = new System.Drawing.Point(657, 50);
            this.Qpanel.Name = "Qpanel";
            this.Qpanel.RowCount = 2;
            this.Qpanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.Qpanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.Qpanel.Size = new System.Drawing.Size(458, 121);
            this.Qpanel.TabIndex = 21;
            this.Qpanel.Paint += new System.Windows.Forms.PaintEventHandler(this.Qpanel_Paint);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label1.Location = new System.Drawing.Point(682, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 23);
            this.label1.TabIndex = 22;
            this.label1.Text = "今日";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.ForeColor = System.Drawing.Color.Green;
            this.label2.Location = new System.Drawing.Point(643, 174);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(286, 23);
            this.label2.TabIndex = 23;
            this.label2.Text = "將新增外包項目:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Qpanel2
            // 
            this.Qpanel2.AutoScroll = true;
            this.Qpanel2.ColumnCount = 6;
            this.Qpanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.Qpanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.Qpanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.Qpanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.Qpanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.Qpanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.Qpanel2.Location = new System.Drawing.Point(657, 200);
            this.Qpanel2.Name = "Qpanel2";
            this.Qpanel2.RowCount = 2;
            this.Qpanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.Qpanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.Qpanel2.Size = new System.Drawing.Size(458, 75);
            this.Qpanel2.TabIndex = 24;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label3.Location = new System.Drawing.Point(819, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 23);
            this.label3.TabIndex = 25;
            this.label3.Text = "外包項目:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // frmQTYname
            // 
            this.frmQTYname.AutoSize = true;
            this.frmQTYname.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.frmQTYname.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.frmQTYname.Location = new System.Drawing.Point(733, 13);
            this.frmQTYname.Name = "frmQTYname";
            this.frmQTYname.Size = new System.Drawing.Size(0, 21);
            this.frmQTYname.TabIndex = 26;
            this.frmQTYname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmQTY
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1218, 639);
            this.Controls.Add(this.frmQTYname);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Qpanel2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Qpanel);
            this.Controls.Add(this.focust);
            this.Controls.Add(this.RIPanel);
            this.Controls.Add(this.btnoutside);
            this.Controls.Add(this.chkouside);
            this.Controls.Add(this.SaveStat);
            this.Controls.Add(this.frmNumshowno);
            this.Controls.Add(this.frmNumRecordnow);
            this.Controls.Add(this.save);
            this.Controls.Add(frmNumbtnD);
            this.Controls.Add(this.frmNumbtnU);
            this.Controls.Add(this.NumPanel);
            this.Name = "frmQTY";
            this.Text = "frmQTY";
            this.Load += new System.EventHandler(this.frmQTY_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox frmNumshowno;
        private System.Windows.Forms.Label frmNumRecordnow;
        private XButton save;
        private System.Windows.Forms.TableLayoutPanel NumPanel;
        private System.Windows.Forms.Button frmNumbtnU;
        private System.Windows.Forms.Label SaveStat;
        private System.Windows.Forms.CheckBox chkouside;
        private XButton btnoutside;
        private System.Windows.Forms.TableLayoutPanel RIPanel;
        private System.Windows.Forms.TextBox focust;
        private System.Windows.Forms.TableLayoutPanel Qpanel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TableLayoutPanel Qpanel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label frmQTYname;
    }
}