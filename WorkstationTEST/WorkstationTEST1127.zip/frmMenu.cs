﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Dapper;
using System.Resources;
using System.Collections;

namespace WorkstationTEST
{
    public partial class frmMenu : Form
    {
        [DllImport("user32.dll", EntryPoint = "FindWindow", CharSet = CharSet.Auto)]
        private extern static IntPtr FindWindow(string lpClassName, string lpWindowName);
        public frmMenu()
        {
            InitializeComponent();
            var load = new loading();
            load.Show();
            dataGridView1.DataSource = getdatatable();
            dataGridView1.Columns[0].HeaderText = "員工編號";
            dataGridView1.Columns[1].HeaderText = "工令編號";
            dataGridView1.Columns[2].HeaderText = "規格";
            dataGridView1.Columns[3].HeaderText = "工作日期";

            dataGridView1.Columns[4].HeaderText = "製程編號";

            dataGridView1.Columns[5].HeaderText = "仕掛數";
            dataGridView1.Columns[6].HeaderText = "完成數";
            dataGridView1.Columns[7].HeaderText = "不良數";
            dataGridView1.Columns[8].HeaderText = "GO完成數";
            dataGridView1.Columns[9].HeaderText = "GO不良數";
            dataGridView1.Columns[10].HeaderText = "NOGO完成數";
            dataGridView1.Columns[11].HeaderText = "NOGO不良數";
            dataGridView1.Columns[12].HeaderText = "工作分鐘數";
            dataGridView1.Columns[13].HeaderText = "製程名稱";
            dataGridView1.Columns[14].HeaderText = "開始時間";
            dataGridView1.Columns[15].HeaderText = "結束時間";
            dataGridView1.Columns[16].HeaderText = "上傳狀態";
            dataGridView1.Columns[17].HeaderText = "單位";           
            load.Close();
           // System.Timers.Timer timer = new System.Timers.Timer(2000);
           // timer.AutoReset = true;
           // timer.Elapsed += new System.Timers.ElapsedEventHandler(HandleTimer);
           // timer.Start();
        }
        public void showmsg()
        {
            Console.WriteLine("call:" + serialPort1.IsOpen);
            if (!serialPort1.IsOpen)
            {
                openseria(sComport);
            }
        }
        private void setport()
        {
            var fstart = false;
            var fend = false;
            var fout = false;
            var fstart2 = false;
            IntPtr ptr = FindWindow("FormSTART", null);
            if (ptr != IntPtr.Zero)
            {
                fstart = true;
            }
            ptr = IntPtr.Zero;
            ptr = FindWindow("FormEND", null);
            if (ptr != IntPtr.Zero)
            {
                fend = true;
            }
            ptr = IntPtr.Zero;
            ptr = FindWindow("FormMain", null);
            if (ptr != IntPtr.Zero)
            {
                fout = true;
            }
            ptr = IntPtr.Zero;
            ptr = FindWindow("FormSTART2", null);
            if (ptr != IntPtr.Zero)
            {
                fstart2 = true;
            }
            ptr = IntPtr.Zero;
            Console.WriteLine("st=" + fstart + ",sn=" + fend + ",so=" + fout);
            if(!fstart && !fend && !fout&&!fstart2)
            {
                try
                {
                    if (serialPort1.IsOpen)
                    {
                        // openseria(sComport);
                        labScannerStatus.Text = "連結";
                    }
                    else
                    {
                        labScannerStatus.Text = "斷開";
                    }
                    
                }
                catch (Exception ex)
                {
                    labScannerStatus.Text = "斷開";
                }
                
            }
            else
            {
                labScannerStatus.Text = "連結";
            }
        }
        void HandleTimer(object sender, System.Timers.ElapsedEventArgs e)
        {
            setport();
        }
        delegate void Display(Byte[] buffer);
        public string sComport = new API("x", "x").COMPORT;
        private void ousidework_Click(object sender, EventArgs e)
        {
            tempclose("o");
        }

        private void frmMenu_Load(object sender, EventArgs e)
        {
            var rtext=CreateElement.loadresx();
            
            Console.WriteLine("load");
            this.WindowState = FormWindowState.Maximized;
            var setpageup = new CreateElement();
            setpageup.SetBtn(startwork, "F1::F1", "開始工作");
            setpageup.SetBtn(start2, "F2::F2", "開始工作2");
            setpageup.SetBtn(endwork, "F3::F3", "結束工作");
            setpageup.SetBtn(ousidework, "F4::F4", "外包");
            SetControlName(rtext);
            this.KeyPreview = true;
            this.Activate();
            this.KeyDown += new KeyEventHandler(mybutton_Click);
            var ip = "59.125.158.96";
            ip = new API("", "").apiip;
            var sqlstat = "";
            var scanstat = "";
           // var com = "COM4";
            //com = new API("", "").COMPORT;
            System.Data.SqlClient.SqlConnection conn =
    new System.Data.SqlClient.SqlConnection();
            conn.ConnectionString =
 "integrated security=false; data source=" + ip + ";" +
 "initial catalog=MISData;persist security info=True;user id=sa;password=Chg8675)$!(;MultipleActiveResultSets=True;    ";
            try
            {
                conn.Open();
                conn.Close();
                sqlstat = "連結";
                laberror.Text = "";
            }
            catch(Exception ex)
            {
                sqlstat = "斷開";
                laberror.Text = ex.Message;
            }
             //SerialPort sport = new SerialPort(com, 115200, Parity.None, 8, StopBits.One);
            try
            {
                if(!serialPort1.IsOpen)
                openseria(sComport);
                scanstat = "連結";
            }
            catch(Exception ex)
            {
                scanstat = "斷開";
                MessageBox.Show("發生錯誤:" + ex);
                Console.WriteLine("無法連結");
            }
            labScannerStatus.Text = scanstat;
            labSQLstatus.Text = sqlstat;
            setselect();

        }

        private void mybutton_Click(object sender, KeyEventArgs e)
        {
            Console.WriteLine("keycoe=" + e.KeyCode);
            setkeymap(e.KeyCode.ToString());
            //tmpb.PerformClick();
        }
        private void endwork_Click(object sender, EventArgs e)
        {
            tempclose("e");
        }

        private void startwork_Click(object sender, EventArgs e)
        {


            // setstart();
            tempclose("s");

        }
        private void tempclose(string frm)
        {
            var CloseDown = new System.Threading.Thread(new System.Threading.ThreadStart(CloseSerialOnExit));
            CloseDown.Start();           
            Console.WriteLine("after start=" + serialPort1.IsOpen);
            var isop = false;
            execfrm(frm);

        }
        private async void execfrm(string frm)
        {
            await Task.Delay(200);
            Console.WriteLine("wait:" + serialPort1.IsOpen);
            if(serialPort1.IsOpen)
            {
                await Task.Delay(800);
                if (frm == "s")
                {
                    var m = new FormSTART(this);
                    m.Show();
                }
                if (frm == "m")
                {
                    var m = new FormSTART2(this);
                    m.Show();
                }
                if (frm=="e")
                {
                    var m = new FormEND(this);
                    m.Show();
                }
                if (frm == "o")
                {
                    var m = new FormMain(this);
                    m.Show();
                }
            }
            else
            {
                if (frm == "s")
                {
                    var m = new FormSTART(this);
                    m.Show();
                }
                if (frm == "m")
                {
                    var m = new FormSTART2(this);
                    m.Show();
                }
                if (frm == "e")
                {
                    var m = new FormEND(this);
                    m.Show();
                }
                if (frm == "o")
                {
                    var m = new FormMain(this);
                    m.Show();
                }
            }
        }
        private void CloseSerialOnExit()
        {

            try
            {
                serialPort1.DtrEnable = false;
                serialPort1.RtsEnable = false;
                serialPort1.DiscardInBuffer();
                serialPort1.DiscardOutBuffer();
                serialPort1.Close();
                if (serialPort1.IsOpen)
                {
                    Console.WriteLine("menuopen");
                }
                else
                {
                    Console.WriteLine("menuclose");

                }
                    
            }
            catch (Exception ex)
            {
                Console.WriteLine("close:" + ex.Message);

            }
        }
        private void setstart()
        {
            var isop = false;
            try
            {
                Console.WriteLine("brfore start=" + serialPort1.IsOpen);
                isop = serialPort1.IsOpen;
                if (serialPort1.IsOpen == true)
                {
                    
                    serialPort1.DtrEnable = false;
                    serialPort1.RtsEnable = false;
                    Thread.Sleep(200);
                    serialPort1.DiscardInBuffer();
                    serialPort1.DiscardOutBuffer();
                    serialPort1.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
            Console.WriteLine("after start=" + isop);
            var m = new FormSTART(this);
            m.Show();
        }
        private void setselect()
        {
            string dbPath = Directory.GetCurrentDirectory() + "\\" + "wd2.db3";
            string cnStr = "data source=" + dbPath + ";Version=3;";
            Console.WriteLine("cn=" + cnStr + ",r" + File.Exists(dbPath));
            List<string> selectemp = new List<string>();
            selectemp.Add(" ");
            if (File.Exists(dbPath))
            {
                using (SQLiteConnection conn = new SQLiteConnection(cnStr))
                {
                    try
                    {
                        var insertscript = "SELECT DISTINCT EmpNo FROM WorkDayReports ORDER BY EmpNo";
                        conn.Open();
                        var cmd = new SQLiteCommand(insertscript, conn);
                        using (SQLiteDataReader row = cmd.ExecuteReader())
                        {
                            while (row.Read())
                            {
                                selectemp.Add(row["EmpNo"] as string ?? "");
                            }
                        }
                     }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                        throw new Exception("錯誤:" + ex.Message);
                    }
                }

            }
            if (selectemp.Count > 0)
            {
                foreach(var item in selectemp)
                {
                    empnolist.Items.Add(new ComboboxItem(item,item));
                }
            }


        }

        private DataTable getdatatable(string empno=" ")
        {
            using (DataTable table = new DataTable())
            {
                // Add columns.
                table.Columns.Add("EmpNo", typeof(string));
                table.Columns.Add("MakeNo", typeof(string));
                table.Columns.Add("Specification", typeof(string));
                table.Columns.Add("WorkDate", typeof(string));
        
                table.Columns.Add("WorkNo", typeof(string));

                table.Columns.Add("WorkQty", typeof(string));
                table.Columns.Add("CompleteQty", typeof(string));
                table.Columns.Add("BadQty", typeof(string));
                table.Columns.Add("CompletGoQty", typeof(string));
                table.Columns.Add("BadGoQty", typeof(string));
                table.Columns.Add("CompletNgQty", typeof(string));
                table.Columns.Add("BadNgQty", typeof(string));
                table.Columns.Add("WorkTime", typeof(string));
                table.Columns.Add("WorkName", typeof(string));
                table.Columns.Add("StartTime", typeof(string));
                table.Columns.Add("EndTime", typeof(string));
                table.Columns.Add("isupdate", typeof(string));
                table.Columns.Add("Unit", typeof(string));
                string dbPath = Directory.GetCurrentDirectory() + "\\" + "wd2.db3";
                string cnStr = "data source=" + dbPath + ";Version=3;";
                Console.WriteLine("cn=" + cnStr + ",r" + File.Exists(dbPath));
                List<WorkDayReportMenu> wkd = new List<WorkDayReportMenu>();
                if (File.Exists(dbPath))
                {
                    using (SQLiteConnection conn = new SQLiteConnection(cnStr))
                    {

                        try
                        {
                            var insertScript = "SELECT * FROM WorkDayReports ORDER BY StartTime DESC";
                            if(empno!=" ")
                                insertScript = "SELECT * FROM WorkDayReports WHERE EmpNo=@EmpNo ORDER BY StartTime DESC";
                            //wkd = conn.Query<WorkDayReport>(insertScript).ToList();
                            conn.Open();
                            var cmd =new SQLiteCommand(insertScript, conn);
                            if(empno!=" ")
                                cmd.Parameters.AddWithValue("@EmpNo", empno);
                            using (SQLiteDataReader row = cmd.ExecuteReader())
                            {
                                while (row.Read())
                                {
                                    wkd.Add(new WorkDayReportMenu() {
                                        DayReportId = row["DayReportId"] as string ?? "",
                                        TenantId = row["TenantId"] as int? ?? default(int),
                                        EmployeeId = row["EmployeeId"] as string ?? "",
                                        EndTime = row["EndTime"] as DateTime? ?? null,
                                        AdjustTime = row["AdjustTime"] as decimal? ?? null,
                                        BadQty = row["BadQty"] as decimal? ?? null,
                                        CompleteQty = row["CompleteQty"] as decimal? ?? null,
                                        BadGoQty = row["BadGoQty"] as decimal? ?? null,
                                        CompletGoQty = row["CompletGoQty"] as decimal? ?? null,
                                        BadNgQty = row["BadNgQty"] as decimal? ?? null,
                                        CompletNgQty = row["CompletNgQty"] as decimal? ?? null,
                                        StartTime = row["StartTime"] as DateTime? ?? null,
                                        WorkDate = row["WorkDate"].ToString(),
                                        WorkId = row["WorkId"] as string ?? "",
                                        WorkOrderId = row["WorkOrderId"] as string ?? "",
                                        WorkOrderItemId = row["WorkOrderItemId"] as string ?? "",
                                        WorkQty = row["WorkQty"] as decimal? ?? null,
                                        Specification = row["Specification"] as string ?? "",
                                        WorkName = row["WorkName"] as string ?? "",
                                        WorkNo = row["WorkNo"] as string ?? "",
                                        MakeNo = row["MakeNo"] as string ?? "",
                                        EmpNo = row["EmpNo"] as string ?? "",
                                        MNo = row["MNo"] as string ?? "",
                                        WorkTime = row["WorkTime"] as decimal? ?? null,
                                        isupdate = row["isupdate"] as Boolean?,
                                        UseUnits=row["Unit"] as string??"",
                                    });
                                }
                            }
                            conn.Close();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                            throw new Exception("錯誤:"+ex.Message);
                        }

                    }
                }
                Console.WriteLine("wkd=" + wkd.Count);
                foreach(var r in wkd.Take(100))
                {
                    DateTime wdate = new DateTime();
                    var isdate = DateTime.TryParse(r.WorkDate, out wdate);
                    Console.WriteLine("en=" + r.EmpNo);
                    table.Rows.Add(r.EmpNo, r.MakeNo, r.Specification,wdate.ToShortDateString(), r.WorkNo, r.WorkQty, r.CompleteQty, r.BadQty,r.CompletGoQty,r.BadGoQty,r.CompletNgQty,r.BadNgQty, r.WorkTime, r.WorkName, r.StartTime,r.EndTime,r.isupdate==true?"成功":(r.WorkTime.HasValue?"失敗":""),r.UseUnits);
                }
                return table;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = getdatatable();
        }
        public void openseria(string com)
        {
            serialPort1.PortName = com;
            serialPort1.BaudRate = 115200;
            serialPort1.DataBits = 8;
            serialPort1.Parity = System.IO.Ports.Parity.None;
            serialPort1.StopBits = System.IO.Ports.StopBits.One;
            if (!serialPort1.IsOpen)
                serialPort1.Open();
            //Console.WriteLine("isopen:"+serialPort1.IsOpen);
        }
        public void setkeymap(string keychar, string data = "", bool isp = false)
        {
            Console.WriteLine(",ind=" + keychar);
            var keyupper = keychar.ToString();
            if (keyupper == "F1")
            {
                Console.WriteLine("eror:");
              //  tempclose();
                startwork.PerformClick();
            }
            if (keyupper == "F3")
            {
                endwork.PerformClick();
            }
            if (keyupper == "F2")
            {
                start2.PerformClick();
            }
            if (keyupper == "F4")
            {
                ousidework.PerformClick();
            }
            if (keyupper == "F5")
            {
                button1.PerformClick();
            }
        }
        public void DisplayText(string clickData)
        { ShowData(clickData); }
        private void DisplayText(Byte[] buffer)
        {
            var scanData = System.Text.Encoding.ASCII.GetString(buffer).ToString().Trim();
            ShowData(scanData);
        }
        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            Byte[] buffer = new Byte[1024];
            Int32 length = (sender as System.IO.Ports.SerialPort).Read(buffer, 0, buffer.Length);
            Array.Resize(ref buffer, length);
            Display d = new Display(DisplayText);
            this.Invoke(d, new Object[] { buffer });
        }

        public string ShowData(string data)
        {
            //Console.WriteLine(data);
            var dataarray = data.Split(new string[] { "::" }, StringSplitOptions.None);
            if (dataarray.Length == 2)
            {
                var pkey = dataarray[1];
                Console.WriteLine("pkey=" + pkey);
                setkeymap(pkey);
            }
            return data;
        }

        private void empnolist_SelectedIndexChanged(object sender, EventArgs e)
        {
            var emp = (ComboBox)sender;
            ComboboxItem selectedCar = (ComboboxItem)emp.SelectedItem;
            dataGridView1.DataSource = getdatatable(selectedCar.Value);
        }

        public void SetControlName(Dictionary<string,string> namelist)
        {
            label1.Text = namelist[label1.Name];
            label23.Text = namelist[label23.Name];
            label2.Text = namelist[label2.Name];
            txtinfo.Text = namelist[txtinfo.Name];
            startwork.LeftText = namelist[startwork.Name];
            endwork.LeftText = namelist[endwork.Name];
            ousidework.LeftText = namelist[ousidework.Name];
            start2.LeftText = namelist[startwork.Name] + "2";
            startwork.Refresh();
            endwork.Refresh();
            ousidework.Refresh();
            start2.Refresh();

            //menu

        }

        public void ChangeLang(string name)
        {
            using (TINI oTINI = new TINI(Path.Combine(Application.StartupPath, "config.ini")))
            {
                oTINI.setKeyValue("SYSTEM", "LANGUAGE", name);
            }
            var dict=CreateElement.loadresx();
            SetControlName(dict);
        }
        private void CHT_Click(object sender, EventArgs e)
        {
            ChangeLang(((Button)sender).Name);
        }

        private void EN_Click(object sender, EventArgs e)
        {
            ChangeLang(((Button)sender).Name);
        }

        private void VN_Click(object sender, EventArgs e)
        {
            ChangeLang(((Button)sender).Name);
        }

        private void start2_Click(object sender, EventArgs e)
        {
            tempclose("m");
        }
    }
}
