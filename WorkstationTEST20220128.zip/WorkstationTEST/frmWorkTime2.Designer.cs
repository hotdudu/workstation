﻿namespace WorkstationTEST
{
    partial class frmWorkTime2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button frmNumbtnD;
            this.SaveStat = new System.Windows.Forms.Label();
            this.frmNumRecordnow = new System.Windows.Forms.Label();
            this.frmNumbtnU = new System.Windows.Forms.Button();
            this.NumPanel = new System.Windows.Forms.TableLayoutPanel();
            this.RPanel = new System.Windows.Forms.TableLayoutPanel();
            this.focust = new System.Windows.Forms.TextBox();
            this.save = new WorkstationTEST.XButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.ermsg = new System.Windows.Forms.TextBox();
            this.msgworktime = new System.Windows.Forms.Label();
            this.msgwork = new System.Windows.Forms.Label();
            this.msgbad = new System.Windows.Forms.Label();
            this.msgcomplet = new System.Windows.Forms.Label();
            this.msgmkno = new System.Windows.Forms.Label();
            this.msgemp = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            frmNumbtnD = new System.Windows.Forms.Button();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // frmNumbtnD
            // 
            frmNumbtnD.Location = new System.Drawing.Point(548, 458);
            frmNumbtnD.Name = "frmNumbtnD";
            frmNumbtnD.Size = new System.Drawing.Size(75, 23);
            frmNumbtnD.TabIndex = 24;
            frmNumbtnD.TabStop = false;
            frmNumbtnD.Text = "frmNumbtnD";
            frmNumbtnD.UseVisualStyleBackColor = true;
            frmNumbtnD.Visible = false;
            // 
            // SaveStat
            // 
            this.SaveStat.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveStat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.SaveStat.Location = new System.Drawing.Point(773, 83);
            this.SaveStat.Name = "SaveStat";
            this.SaveStat.Size = new System.Drawing.Size(164, 33);
            this.SaveStat.TabIndex = 27;
            this.SaveStat.Text = "label1";
            this.SaveStat.Visible = false;
            // 
            // frmNumRecordnow
            // 
            this.frmNumRecordnow.AutoSize = true;
            this.frmNumRecordnow.Location = new System.Drawing.Point(361, 556);
            this.frmNumRecordnow.Name = "frmNumRecordnow";
            this.frmNumRecordnow.Size = new System.Drawing.Size(99, 12);
            this.frmNumRecordnow.TabIndex = 25;
            this.frmNumRecordnow.Text = "frmNumRecordnow";
            this.frmNumRecordnow.Visible = false;
            // 
            // frmNumbtnU
            // 
            this.frmNumbtnU.Location = new System.Drawing.Point(548, 188);
            this.frmNumbtnU.Name = "frmNumbtnU";
            this.frmNumbtnU.Size = new System.Drawing.Size(75, 23);
            this.frmNumbtnU.TabIndex = 23;
            this.frmNumbtnU.TabStop = false;
            this.frmNumbtnU.Text = "frmNumbtnU";
            this.frmNumbtnU.UseVisualStyleBackColor = true;
            this.frmNumbtnU.Visible = false;
            // 
            // NumPanel
            // 
            this.NumPanel.AutoSize = true;
            this.NumPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.NumPanel.ColumnCount = 4;
            this.NumPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.NumPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.NumPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.NumPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.NumPanel.Location = new System.Drawing.Point(0, 110);
            this.NumPanel.Margin = new System.Windows.Forms.Padding(1);
            this.NumPanel.Name = "NumPanel";
            this.NumPanel.RowCount = 3;
            this.NumPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.NumPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.NumPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.NumPanel.Size = new System.Drawing.Size(0, 0);
            this.NumPanel.TabIndex = 28;
            // 
            // RPanel
            // 
            this.RPanel.AutoSize = true;
            this.RPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.RPanel.ColumnCount = 13;
            this.RPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.RPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.RPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.RPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.RPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.RPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.RPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.RPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.RPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.RPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.RPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.RPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.RPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.RPanel.Location = new System.Drawing.Point(5, 21);
            this.RPanel.Name = "RPanel";
            this.RPanel.RowCount = 2;
            this.RPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.RPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.RPanel.Size = new System.Drawing.Size(0, 0);
            this.RPanel.TabIndex = 29;
            // 
            // focust
            // 
            this.focust.Location = new System.Drawing.Point(735, 459);
            this.focust.Name = "focust";
            this.focust.Size = new System.Drawing.Size(100, 22);
            this.focust.TabIndex = 31;
            this.focust.Visible = false;
            // 
            // save
            // 
            this.save.LeftText = null;
            this.save.Location = new System.Drawing.Point(773, 365);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(75, 23);
            this.save.TabIndex = 30;
            this.save.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.save.TopText = null;
            this.save.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.ermsg);
            this.panel3.Controls.Add(this.msgworktime);
            this.panel3.Controls.Add(this.msgwork);
            this.panel3.Controls.Add(this.msgbad);
            this.panel3.Controls.Add(this.msgcomplet);
            this.panel3.Controls.Add(this.msgmkno);
            this.panel3.Controls.Add(this.msgemp);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Location = new System.Drawing.Point(750, 18);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(359, 341);
            this.panel3.TabIndex = 33;
            // 
            // ermsg
            // 
            this.ermsg.BackColor = System.Drawing.SystemColors.Control;
            this.ermsg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ermsg.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ermsg.ForeColor = System.Drawing.Color.Red;
            this.ermsg.Location = new System.Drawing.Point(11, 249);
            this.ermsg.Multiline = true;
            this.ermsg.Name = "ermsg";
            this.ermsg.Size = new System.Drawing.Size(330, 79);
            this.ermsg.TabIndex = 25;
            this.ermsg.TabStop = false;
            this.ermsg.Visible = false;
            // 
            // msgworktime
            // 
            this.msgworktime.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.msgworktime.ForeColor = System.Drawing.Color.Blue;
            this.msgworktime.Location = new System.Drawing.Point(145, 214);
            this.msgworktime.Name = "msgworktime";
            this.msgworktime.Size = new System.Drawing.Size(175, 23);
            this.msgworktime.TabIndex = 24;
            this.msgworktime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // msgwork
            // 
            this.msgwork.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.msgwork.ForeColor = System.Drawing.Color.Blue;
            this.msgwork.Location = new System.Drawing.Point(145, 180);
            this.msgwork.Name = "msgwork";
            this.msgwork.Size = new System.Drawing.Size(196, 23);
            this.msgwork.TabIndex = 23;
            this.msgwork.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // msgbad
            // 
            this.msgbad.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.msgbad.ForeColor = System.Drawing.Color.Blue;
            this.msgbad.Location = new System.Drawing.Point(145, 146);
            this.msgbad.Name = "msgbad";
            this.msgbad.Size = new System.Drawing.Size(100, 23);
            this.msgbad.TabIndex = 22;
            this.msgbad.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // msgcomplet
            // 
            this.msgcomplet.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.msgcomplet.ForeColor = System.Drawing.Color.Blue;
            this.msgcomplet.Location = new System.Drawing.Point(145, 114);
            this.msgcomplet.Name = "msgcomplet";
            this.msgcomplet.Size = new System.Drawing.Size(100, 23);
            this.msgcomplet.TabIndex = 21;
            this.msgcomplet.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // msgmkno
            // 
            this.msgmkno.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.msgmkno.ForeColor = System.Drawing.Color.Blue;
            this.msgmkno.Location = new System.Drawing.Point(145, 79);
            this.msgmkno.Name = "msgmkno";
            this.msgmkno.Size = new System.Drawing.Size(175, 23);
            this.msgmkno.TabIndex = 20;
            this.msgmkno.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // msgemp
            // 
            this.msgemp.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.msgemp.ForeColor = System.Drawing.Color.Blue;
            this.msgemp.Location = new System.Drawing.Point(145, 41);
            this.msgemp.Name = "msgemp";
            this.msgemp.Size = new System.Drawing.Size(175, 23);
            this.msgemp.TabIndex = 19;
            this.msgemp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(5, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 24);
            this.label3.TabIndex = 18;
            this.label3.Text = "不良數";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(5, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 24);
            this.label2.TabIndex = 17;
            this.label2.Text = "完成數";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(5, 213);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 24);
            this.label1.TabIndex = 16;
            this.label1.Text = "工時";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label21.Location = new System.Drawing.Point(5, 179);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(58, 24);
            this.label21.TabIndex = 14;
            this.label21.Text = "製程";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.Location = new System.Drawing.Point(5, 78);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(106, 24);
            this.label13.TabIndex = 6;
            this.label13.Text = "工令編號";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label12.Location = new System.Drawing.Point(5, 40);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 24);
            this.label12.TabIndex = 5;
            this.label12.Text = "員工";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.label7.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label7.Location = new System.Drawing.Point(81, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(142, 24);
            this.label7.TabIndex = 0;
            this.label7.Text = "將新增資料:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(608, 105);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(10, 23);
            this.button1.TabIndex = 32;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(929, 370);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 12);
            this.label4.TabIndex = 34;
            this.label4.Text = "label4";
            this.label4.Visible = false;
            // 
            // frmWorkTime2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1143, 605);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.focust);
            this.Controls.Add(this.save);
            this.Controls.Add(this.RPanel);
            this.Controls.Add(this.NumPanel);
            this.Controls.Add(this.SaveStat);
            this.Controls.Add(this.frmNumRecordnow);
            this.Controls.Add(frmNumbtnD);
            this.Controls.Add(this.frmNumbtnU);
            this.Name = "frmWorkTime2";
            this.Text = "frmWorkTime";
            this.Load += new System.EventHandler(this.frmWorkTime_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label SaveStat;
        private System.Windows.Forms.Label frmNumRecordnow;
        private System.Windows.Forms.Button frmNumbtnU;
        private System.Windows.Forms.TableLayoutPanel NumPanel;
        private System.Windows.Forms.TableLayoutPanel RPanel;
        private System.Windows.Forms.TextBox focust;
        private XButton save;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label msgworktime;
        private System.Windows.Forms.Label msgwork;
        private System.Windows.Forms.Label msgbad;
        private System.Windows.Forms.Label msgcomplet;
        private System.Windows.Forms.Label msgmkno;
        private System.Windows.Forms.Label msgemp;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox ermsg;
    }
}